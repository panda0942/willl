function myFunction() {
    document.getElementById("navlisti").classList.toggle("show");
}
window.onclick=function(event){
    if(!event.target.matches('.buttonN')){
        var dropdowns = document.getElementsByClassName("navlist1");
        var i;
        for( i = 0; i<dropdowns.length; i++){
            var opendropdown = dropdowns[i];
            if(opendropdown.classList.contains('show')){
                opendropdown.classList.remove('show');
            }
        }
    }
}

function pressMe() {
    document.getElementById("navlistii").classList.toggle("show");
}
window.onclick=function(event){
    if(!event.target.matches('.buttonM')){
        var dropdowns = document.getElementsByClassName("navlist2");
        var i;
        for( i = 0; i<dropdowns.length; i++){
            var opendropdown = dropdowns[i];
            if(opendropdown.classList.contains('show')){
                opendropdown.classList.remove('show');
            }
        }
    }
}

function myFunction2() {
    document.getElementById("navlistiii").classList.toggle("show");
}
window.onclick=function(event){
    if(!event.target.matches('.buttonO')){
        var dropdowns = document.getElementsByClassName("navlist3");
        var i;
        for( i = 0; i<dropdowns.length; i++){
            var opendropdown = dropdowns[i];
            if(opendropdown.classList.contains('show')){
                opendropdown.classList.remove('show');
            }
        }
    }
}

function myFunction3() {
    document.getElementById("navlistiv").classList.toggle("show");
}
window.onclick=function(event){
    if(!event.target.matches('.buttonP')){
        var dropdowns = document.getElementsByClassName("navlist4");
        var i;
        for( i = 0; i<dropdowns.length; i++){
            var opendropdown = dropdowns[i];
            if(opendropdown.classList.contains('show')){
                opendropdown.classList.remove('show');
            }
        }
    }
}

function myFunction4() {
    document.getElementById("navlistv").classList.toggle("show");
}
window.onclick=function(event){
    if(!event.target.matches('.buttonQ')){
        var dropdowns = document.getElementsByClassName("navlist5");
        var i;
        for( i = 0; i<dropdowns.length; i++){
            var opendropdown = dropdowns[i];
            if(opendropdown.classList.contains('show')){
                opendropdown.classList.remove('show');
            }
        }
    }
}

function myFunction5() {
    document.getElementById("navlistvi").classList.toggle("show");
}
window.onclick=function(event){
    if(!event.target.matches('.buttonR')){
        var dropdowns = document.getElementsByClassName("navlist6");
        var i;
        for( i = 0; i<dropdowns.length; i++){
            var opendropdown = dropdowns[i];
            if(opendropdown.classList.contains('show')){
                opendropdown.classList.remove('show');
            }
        }
    }
}